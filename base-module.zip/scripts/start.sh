#!/system/bin/sh
MODDIR=/data/adb/modules/samba_webui_armv7
STATE=/data/adb/samba-webui
BIN="$MODDIR/bin"
CONF="$STATE/smb.conf"
LOG="$STATE/module.log"
. "$MODDIR/scripts/common.sh"

get_device_ip() {
  ip -o -4 addr show 2>/dev/null | awk '$3 == "inet" && $2 != "lo" { sub(/\/.*/, "", $4); print $4; exit }'
}

mkdir -p "$STATE/private" "$STATE/lock" "$STATE/state" "$STATE/cache" "$STATE/log" "$STATE/ncalrpc" /data/samba/var/run/ncalrpc
echo "[$(date)] start requested v1.0.7" >> "$LOG"
if [ ! -f "$STATE/settings.conf" ]; then
  echo 'Сначала сохраните пользователя SMB в WebUI.' > "$STATE/status.txt"
  echo "settings.conf missing" >> "$LOG"
  exit 1
fi
. "$STATE/settings.conf"
[ -f "$STATE/shares.tsv" ] || : > "$STATE/shares.tsv"
/system/bin/sh "$MODDIR/scripts/make-config.sh" >> "$LOG" 2>&1
cfg_rc=$?
if [ "$cfg_rc" -ne 0 ] || [ ! -s "$CONF" ]; then
  echo 'Не удалось создать smb.conf. Подробности: module.log' > "$STATE/status.txt"
  echo "make-config failed rc=$cfg_rc conf_exists=$( [ -s "$CONF" ] && echo yes || echo no )" >> "$LOG"
  exit 1
fi
# Samba can keep a valid PID file even when Android's pidof does not find the process.
if [ -s "$STATE/smbd.pid" ]; then
  oldpid="$(cat "$STATE/smbd.pid" 2>/dev/null)"
  case "$oldpid" in
    ''|*[!0-9]*) rm -f "$STATE/smbd.pid" ;;
    *)
      if kill -0 "$oldpid" 2>/dev/null; then
        cmdline="$(tr '\\000' ' ' < "/proc/$oldpid/cmdline" 2>/dev/null)"
        if echo "$cmdline" | grep -q 'smbd'; then
          ipaddr="$(get_device_ip)"; [ -n "$ipaddr" ] || ipaddr="не определён"; echo "Samba работает. Пользователь: $SMB_USER. Адрес устройства: $ipaddr. SMB-порт: 445." > "$STATE/status.txt"
          echo "valid existing smbd pid=$oldpid cmdline=$cmdline" >> "$LOG"
          exit 0
        fi
      fi
      rm -f "$STATE/smbd.pid"
      ;;
  esac
fi
pids="$(pidof smbd 2>/dev/null)"
if [ -n "$pids" ]; then
  echo "$pids" > "$STATE/smbd.pid"
  ipaddr="$(get_device_ip)"; [ -n "$ipaddr" ] || ipaddr="не определён"; echo "Samba работает. Пользователь: $SMB_USER. Адрес устройства: $ipaddr. SMB-порт: 445." > "$STATE/status.txt"
  echo "smbd already running pid=$pids" >> "$LOG"
  exit 0
fi
export LD_LIBRARY_PATH="$MODDIR/lib:$MODDIR/lib/private"
export TMPDIR=/data/local/tmp
echo "Running: $BIN/smbd -s $CONF -D" >> "$LOG"
"$BIN/smbd" -s "$CONF" -D >> "$LOG" 2>&1
rc=$?
sleep 2
pids="$(pidof smbd 2>/dev/null)"
if [ -n "$pids" ]; then
  echo "$pids" > "$STATE/smbd.pid"
  ipaddr="$(get_device_ip)"; [ -n "$ipaddr" ] || ipaddr="не определён"; echo "Samba запущена. Пользователь: $SMB_USER. Адрес устройства: $ipaddr. SMB-порт: 445." > "$STATE/status.txt"
  echo "smbd running after launch rc=$rc pid=$pids" >> "$LOG"
  exit 0
fi
if [ -s "$STATE/smbd.pid" ]; then
  oldpid="$(cat "$STATE/smbd.pid" 2>/dev/null)"
  case "$oldpid" in ''|*[!0-9]*) ;; *)
    if kill -0 "$oldpid" 2>/dev/null; then
      cmdline="$(tr '\\000' ' ' < "/proc/$oldpid/cmdline" 2>/dev/null)"
      if echo "$cmdline" | grep -q 'smbd'; then
        ipaddr="$(get_device_ip)"; [ -n "$ipaddr" ] || ipaddr="не определён"; echo "Samba запущена. Адрес устройства: $ipaddr. SMB-порт: 445." > "$STATE/status.txt"
        echo "smbd validated from pidfile pid=$oldpid cmdline=$cmdline" >> "$LOG"
        exit 0
      fi
    fi ;;
  esac
fi
echo "smbd не обнаружен после запуска (код команды $rc). См. module.log и каталог log/." > "$STATE/status.txt"
echo "smbd not detected rc=$rc; pidof empty" >> "$LOG"
exit 1
