#!/system/bin/sh
. "${0%/*}/common.sh"
LOG="$STATE/module.log"
if [ -f "$STATE/smbd.pid" ]; then
  pid="$(cat "$STATE/smbd.pid" 2>/dev/null)"
  case "$pid" in ''|*[!0-9]*) ;; *) kill "$pid" 2>>"$LOG" || true ;; esac
  rm -f "$STATE/smbd.pid"
fi
echo 'Остановка Samba запрошена.' > "$STATE/status.txt"
echo "[$(date)] stop requested" >> "$LOG"
