#!/system/bin/sh
MODDIR=/data/adb/modules/samba_webui_armv7
STATE=/data/adb/samba-webui
CONF="$STATE/smb.conf"
LOG="$STATE/module.log"
mkdir -p "$STATE/private" "$STATE/lock" "$STATE/state" "$STATE/cache" "$STATE/log" "$STATE/ncalrpc"
# This Samba build has a compiled-in fallback path for its NCalRPC pipe directory.
mkdir -p /data/samba/var/run/ncalrpc 2>>"$LOG"
chmod 700 "$STATE" "$STATE/private" "$STATE/ncalrpc" 2>/dev/null
[ -f "$STATE/settings.conf" ] || { echo "settings.conf missing" >> "$LOG"; exit 1; }
. "$STATE/settings.conf"
[ -f "$STATE/shares.tsv" ] || : > "$STATE/shares.tsv"
{
  echo '[global]'
  echo 'workgroup = WORKGROUP'
  echo 'server string = Android Samba'
  echo 'security = user'
  echo 'map to guest = Never'
  echo 'server min protocol = SMB2_02'
  echo 'smb ports = 445'
  echo "private dir = $STATE/private"
  echo "lock directory = $STATE/lock"
  echo "state directory = $STATE/state"
  echo "cache directory = $STATE/cache"
  echo "pid directory = $STATE"
  echo "ncalrpc dir = $STATE/ncalrpc"
  echo "log file = $STATE/log/log.%m"
  echo 'max log size = 500'
  echo 'load printers = no'
  echo 'disable spoolss = yes'
  while IFS="$(printf '\t')" read -r name path readonly; do
    [ -n "$name" ] || continue
    [ -d "$path" ] || { echo "Share path not found: $path" >> "$LOG"; continue; }
    case "$name$path" in *'['*|*']'*|*'%'*|*'='*|*'	'*) echo "Invalid share name/path" >> "$LOG"; continue ;; esac
    echo "[$name]"
    echo " path = $path"
    echo ' browseable = yes'
    echo ' guest ok = no'
    echo " valid users = $SMB_USER"
    if [ "$readonly" = "no" ]; then echo ' read only = no'; else echo ' read only = yes'; fi
  done < "$STATE/shares.tsv"
} > "$CONF" || { echo "config write failed: $CONF" >> "$LOG"; exit 1; }
chmod 600 "$CONF"
[ -s "$CONF" ] || { echo "config empty: $CONF" >> "$LOG"; exit 1; }
