#!/system/bin/sh
. "${0%/*}/common.sh"
fail(){ echo "Ошибка: $1"; exit 1; }
valid_user(){ case "$1" in ''|*[!A-Za-z0-9._-]*) return 1;; esac; [ "${#1}" -le 32 ]; }
valid_share(){ case "$1" in ''|*[!A-Za-z0-9_.\ -]*) return 1;; esac; [ "${#1}" -le 48 ]; }
valid_path(){ case "$1" in /*) ;; *) return 1;; esac; case "$1" in *'|'*|*'['*|*']'*|*'='*|*'\'*|*'\t'*|*'\n'*) return 1;; esac; [ -d "$1" ]; }
case "$ACTION" in
  user)
    valid_user "$SMB_USER" || fail 'неверное имя пользователя'
    [ "${#SMB_PASSWORD}" -ge 8 ] || fail 'пароль должен быть не короче 8 символов'
    # Prevent config injection and store the user in a root-only settings file.
    printf 'SMB_USER=%s\n' "$SMB_USER" > "$STATE/settings.conf"
    chmod 600 "$STATE/settings.conf"
    /system/bin/sh "${0%/*}/make-config.sh" || fail 'не удалось создать конфигурацию'
    # smbpasswd may require a matching local Unix account in some Samba builds; report failure rather than pretend success.
    printf '%s\n%s\n' "$SMB_PASSWORD" "$SMB_PASSWORD" | "$BIN/smbpasswd" -s -a -c "$CONF" "$SMB_USER" >/dev/null 2>&1 || fail 'smbpasswd не смог создать пользователя (сборка Samba может требовать системную UNIX-учётную запись)'
    unset SMB_PASSWORD
    /system/bin/sh "$MODDIR/scripts/start.sh" >/dev/null 2>&1 || fail 'пользователь создан, но smbd не запустился; см. status.txt'
    echo 'Пользователь сохранён, Samba запущена.'
    ;;
  share)
    valid_share "$SHARE_NAME" || fail 'неверное имя ресурса'
    valid_path "$SHARE_PATH" || fail 'путь должен быть абсолютным и вести к существующей папке'
    case "$SHARE_READONLY" in no) ro=no;; *) ro=yes;; esac
    touch "$STATE/shares.tsv"
    awk -F '\t' -v n="$SHARE_NAME" '$1!=n{print}' "$STATE/shares.tsv" > "$STATE/shares.tmp"
    printf '%s\t%s\t%s\n' "$SHARE_NAME" "$SHARE_PATH" "$ro" >> "$STATE/shares.tmp"
    mv "$STATE/shares.tmp" "$STATE/shares.tsv"
    /system/bin/sh "$MODDIR/scripts/start.sh" >/dev/null 2>&1 || echo 'Папка сохранена; Samba пока не запущена.'
    echo 'Общая папка сохранена.'
    ;;
  delshare)
    valid_share "$SHARE_NAME" || fail 'неверное имя ресурса'
    [ -f "$STATE/shares.tsv" ] || : > "$STATE/shares.tsv"
    awk -F '\t' -v n="$SHARE_NAME" '$1!=n{print}' "$STATE/shares.tsv" > "$STATE/shares.tmp"
    mv "$STATE/shares.tmp" "$STATE/shares.tsv"
    /system/bin/sh "$MODDIR/scripts/start.sh" >/dev/null 2>&1 || true
    echo 'Общая папка удалена.'
    ;;
  start) /system/bin/sh "$MODDIR/scripts/start.sh" || fail 'запуск не удался'; echo 'Samba запущена.' ;;
  stop) /system/bin/sh "$MODDIR/scripts/stop.sh"; echo 'Samba остановлена.' ;;
  *) fail 'неизвестная операция' ;;
esac
