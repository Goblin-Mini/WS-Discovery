#!/system/bin/sh
STATE=/data/adb/samba-webui
if [ -f "$STATE/status.txt" ]; then
  cat "$STATE/status.txt"
else
  echo 'Samba пока не настроена.'
fi
if [ -f "$STATE/webui.pid" ]; then
  pid="$(cat "$STATE/webui.pid" 2>/dev/null)"
  case "$pid" in ''|*[!0-9]*) echo 'WebUI PID некорректен.' ;; *) kill -0 "$pid" 2>/dev/null && echo "WebUI работает (PID: $pid)." || echo "WebUI завершился (PID: $pid)." ;; esac
else
  echo 'WebUI PID file отсутствует.'
fi
if [ -f "$STATE/module.log" ]; then
  echo 'Последние записи журнала:'
  tail -n 12 "$STATE/module.log"
fi
