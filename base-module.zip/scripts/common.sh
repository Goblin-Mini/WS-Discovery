#!/system/bin/sh
MODDIR=/data/adb/modules/samba_webui_armv7
STATE=/data/adb/samba-webui
BIN="$MODDIR/bin"
CONF="$STATE/smb.conf"
export LD_LIBRARY_PATH="$MODDIR/lib:$MODDIR/lib/private"
export TMPDIR=/data/local/tmp
mkdir -p "$STATE/private" "$STATE/lock" "$STATE/state" "$STATE/cache" "$STATE/log"
chmod 700 "$STATE" "$STATE/private" 2>/dev/null
