#!/system/bin/sh
# Configuration and Samba password database remain in /data/adb/samba-webui.
