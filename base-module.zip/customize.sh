#!/system/bin/sh
ui_print "Samba Server WebUI — ARMv7 / ARM64 compat"
ABI="$(getprop ro.product.cpu.abi)"
ABI32="$(getprop ro.product.cpu.abilist32)"
case "$ABI" in
  armeabi-v7a|armeabi) ui_print "32-bit ARM detected." ;;
  arm64-v8a)
    case ",$ABI32," in
      *,armeabi-v7a,*|*,armeabi,*) ui_print "ARM64 with 32-bit ARM runtime detected." ;;
      *) ui_print "! ARM64-only device: this archive contains ARMv7 binaries."; abort ;;
    esac ;;
  *) ui_print "! Unsupported ABI: $ABI"; abort ;;
esac

# APatch installer variants may not export MODPATH consistently. Resolve the
# extracted module directory, then restore executable bits before checking.
MODDIR="${MODPATH:-}"
if [ -z "$MODDIR" ] || [ ! -d "$MODDIR/bin" ]; then
  HERE="$(dirname "$0")"
  [ -d "$HERE/bin" ] && MODDIR="$HERE"
fi
if [ -z "$MODDIR" ] || [ ! -d "$MODDIR/bin" ]; then
  [ -d "$PWD/bin" ] && MODDIR="$PWD"
fi
if [ -z "$MODDIR" ] || [ ! -d "$MODDIR/bin" ]; then
  ui_print "! Cannot locate extracted module bin/ directory."
  ui_print "! Installer working directory: $PWD"
  ui_print "! MODPATH: ${MODPATH:-<unset>}"
  abort
fi

chmod 0755 "$MODDIR"/bin/smbd "$MODDIR"/bin/smbpasswd "$MODDIR"/bin/nmbd "$MODDIR"/bin/webui 2>/dev/null
for f in smbd smbpasswd webui; do
  if [ ! -f "$MODDIR/bin/$f" ]; then
    ui_print "! Missing file: $MODDIR/bin/$f"
    ui_print "Contents of $MODDIR/bin:"
    ls -la "$MODDIR/bin" 2>/dev/null
    abort
  fi
done
ui_print "Found bundled files in $MODDIR/bin."
ui_print "Executable permissions restored."
