#!/system/bin/sh
MODDIR=/data/adb/modules/samba_webui_armv7
STATE="/data/adb/samba-webui"
mkdir -p "$STATE/private" "$STATE/lock" "$STATE/state" "$STATE/cache" "$STATE/log"
chmod 700 "$STATE" "$STATE/private" 2>/dev/null
for f in smbd smbpasswd nmbd webui webui_compact; do
  if [ ! -f "$MODDIR/bin/$f" ]; then
    echo "Отсутствует бинарник: $MODDIR/bin/$f" > "$STATE/status.txt"
    exit 1
  fi
done
chmod 0755 "$MODDIR"/bin/smbd "$MODDIR"/bin/smbpasswd "$MODDIR"/bin/nmbd "$MODDIR"/bin/webui "$MODDIR"/bin/webui_compact 2>/dev/null
ABI="$(getprop ro.product.cpu.abi)"
ABI32="$(getprop ro.product.cpu.abilist32)"
if [ "$ABI" = "arm64-v8a" ]; then
  case ",$ABI32," in *,armeabi-v7a,*|*,armeabi,*) ;; *) echo "Нужна поддержка 32-bit ARM." > "$STATE/status.txt"; exit 1 ;; esac
fi
while [ "$(getprop sys.boot_completed)" != "1" ]; do sleep 2; done
sleep 2
export LD_LIBRARY_PATH="$MODDIR/lib:$MODDIR/lib/private"
export TMPDIR=/data/local/tmp
# Keep the original WebUI as a fallback on 8765 and start the compact dashboard on 8766.
"$MODDIR/bin/webui" >> "$STATE/webui.log" 2>&1 &
echo $! > "$STATE/webui.pid"
"$MODDIR/bin/webui_compact" >> "$STATE/webui_compact.log" 2>&1 &
echo $! > "$STATE/webui_compact.pid"
sleep 2
wpid="$(cat "$STATE/webui.pid" 2>/dev/null)"
cpid="$(cat "$STATE/webui_compact.pid" 2>/dev/null)"
if ! kill -0 "$wpid" 2>/dev/null && ! kill -0 "$cpid" 2>/dev/null; then
  echo "WebUI не запустился. См. $STATE/webui.log и webui_compact.log" > "$STATE/status.txt"
  echo "Both WebUI processes exited after launch" >> "$STATE/module.log"
  exit 1
fi
kill -0 "$wpid" 2>/dev/null && echo "WebUI started pid=$wpid port=8765" >> "$STATE/module.log"
kill -0 "$cpid" 2>/dev/null && echo "Compact WebUI started pid=$cpid port=8766" >> "$STATE/module.log"

# Ensure settings exist, but do not overwrite a valid existing account.
if [ ! -f "$STATE/settings.conf" ] || ! grep -q '^SMB_USER=[A-Za-z0-9._-][A-Za-z0-9._-]*$' "$STATE/settings.conf" 2>/dev/null; then
  umask 077
  printf 'SMB_USER=admin\n' > "$STATE/settings.conf"
  chmod 600 "$STATE/settings.conf"
fi

# Ensure essential default shares exist even when an older non-empty shares.tsv is present.
# Preserve user-defined shares; add only missing names/paths.
umask 077
[ -f "$STATE/shares.tsv" ] || : > "$STATE/shares.tsv"
if ! awk -F '\t' '$1 == "Root" || $2 == "/" { found=1 } END { exit !found }' "$STATE/shares.tsv"; then
  printf 'Root\t/\tno\n' >> "$STATE/shares.tsv"
fi
if [ -d /storage/emulated/0 ] && ! awk -F '\t' '$1 == "Internal" || $2 == "/storage/emulated/0" { found=1 } END { exit !found }' "$STATE/shares.tsv"; then
  printf 'Memory\t/storage/emulated/0\tno\n' >> "$STATE/shares.tsv"
fi
chmod 600 "$STATE/shares.tsv"
awk -F '\t' 'BEGIN{OFS="\t"} $1=="Internal" {$1="Memory"} {print}' "$STATE/shares.tsv" > "$STATE/shares.rename" && mv "$STATE/shares.rename" "$STATE/shares.tsv"
chmod 600 "$STATE/shares.tsv"

# Expose removable SD/USB volumes. Android may mount at /mnt/media_rw/UUID
# and expose a matching /storage/UUID path rather than mounting directly under /storage.
if [ -f "$STATE/shares.tsv" ]; then
  awk -F '\t' '$2 != "/storage" { print }' "$STATE/shares.tsv" > "$STATE/shares.filtered"
  mv "$STATE/shares.filtered" "$STATE/shares.tsv"
  chmod 600 "$STATE/shares.tsv"
  idx=1
  for mnt in /storage/* /mnt/media_rw/*; do
    [ -d "$mnt" ] || continue
    base="${mnt##*/}"
    case "$base" in emulated|self|XXXX-XXXX) continue;; esac
    # Skip standard virtual storage directories; keep UUID-like removable volume names.
    case "$base" in
      *-*) ;;
      *) continue;;
    esac
    # Require evidence of a mounted volume or Android's removable-volume backing path.
    found=no
    grep -Fq " $mnt " /proc/mounts 2>/dev/null && found=yes
    [ -d "/mnt/media_rw/$base" ] && found=yes
    [ "$found" = yes ] || continue
    sharepath="$mnt"
    if [ -d "/storage/$base" ]; then sharepath="/storage/$base"; fi
    if ! awk -F '\t' -v p="$sharepath" '$2 == p { found=1 } END { exit !found }' "$STATE/shares.tsv"; then
      name="SD Card"
      while awk -F '\t' -v n="$name" '$1 == n { found=1 } END { exit !found }' "$STATE/shares.tsv"; do idx=$((idx+1)); name="USB Disk $idx"; done
      printf '%s\t%s\tno\n' "$name" "$sharepath" >> "$STATE/shares.tsv"
      idx=$((idx + 1))
    fi
  done
fi

# Android TV often mounts USB/SD volumes after the module service starts. Rescan for a short period.
# Add missing shares for UUID-backed volumes, preserving existing shares and names.
scan_removable() {
  [ -f "$STATE/shares.tsv" ] || : > "$STATE/shares.tsv"
  idx=1
  for mnt in /storage/* /mnt/media_rw/*; do
    [ -d "$mnt" ] || continue
    base="${mnt##*/}"
    case "$base" in emulated|self|XXXX-XXXX) continue;; esac
    case "$base" in *-*) ;; *) continue;; esac
    [ -d "/mnt/media_rw/$base" ] || grep -Fq " $mnt " /proc/mounts 2>/dev/null || continue
    sharepath="$mnt"
    [ -d "/storage/$base" ] && sharepath="/storage/$base"
    if ! awk -F '\t' -v p="$sharepath" '$2 == p { found=1 } END { exit !found }' "$STATE/shares.tsv"; then
      name="SD Card"
      while awk -F '\t' -v n="$name" '$1 == n { found=1 } END { exit !found }' "$STATE/shares.tsv"; do idx=$((idx+1)); name="USB Disk $idx"; done
      printf '%s\t%s\tno\n' "$name" "$sharepath" >> "$STATE/shares.tsv"
      idx=$((idx+1))
    fi
  done
  chmod 600 "$STATE/shares.tsv"
}
# Rebuild smb.conf after ensuring the share list exists; this does not reset the SMB password.
/system/bin/sh "$MODDIR/scripts/make-config.sh" >> "$STATE/module.log" 2>&1

# Ensure the requested default SMB account exists on first install/repair.
# A marker prevents resetting the password on every reboot.
if [ -f "$STATE/settings.conf" ] && grep -q '^SMB_USER=admin$' "$STATE/settings.conf" && [ ! -f "$STATE/.admin_defaults_initialized" ] && [ -s "$STATE/smb.conf" ]; then
  if printf 'administrator\nadministrator\n' | "$MODDIR/bin/smbpasswd" -s -a -c "$STATE/smb.conf" admin >> "$STATE/module.log" 2>&1; then
    touch "$STATE/.admin_defaults_initialized"
    chmod 600 "$STATE/.admin_defaults_initialized"
    echo "Default SMB user admin initialized" >> "$STATE/module.log"
  else
    echo "ERROR: failed to initialize default SMB user admin" >> "$STATE/module.log"
  fi
fi

if [ -f "$STATE/settings.conf" ]; then
  /system/bin/sh "$MODDIR/scripts/start.sh" >> "$STATE/module.log" 2>&1
fi

# Late-mounted SD/USB volumes: poll for up to 60 seconds after boot.
scan_round=0
while [ "$scan_round" -lt 6 ]; do
  sleep 10
  before="$(cksum "$STATE/shares.tsv" 2>/dev/null)"
  scan_removable
  after="$(cksum "$STATE/shares.tsv" 2>/dev/null)"
  if [ "$before" != "$after" ]; then
    /system/bin/sh "$MODDIR/scripts/make-config.sh" >> "$STATE/module.log" 2>&1
    /system/bin/sh "$MODDIR/scripts/start.sh" >> "$STATE/module.log" 2>&1
    echo "Removable shares refreshed after boot" >> "$STATE/module.log"
  fi
  scan_round=$((scan_round+1))
done
