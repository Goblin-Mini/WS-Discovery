#!/system/bin/sh
MODDIR="${0%/*}"
"$MODDIR/scripts/status.sh"
