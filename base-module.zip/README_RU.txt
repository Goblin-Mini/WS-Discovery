Samba Server WebUI v1.0 — ARMv7 / APatch / Magisk
- Bundled WebUI binary replaced with a local-only HTTP interface.
- Forms use POST requests; the password is not put in the URL.
- WebUI binds to 127.0.0.1:8765 only.
- State/logs: /data/adb/samba-webui/
- This build is cross-compiled for 32-bit ARM (ARMv7). On ARM64 it requires 32-bit ARM runtime support.
- Network share availability still depends on Samba binary compatibility, Android permissions, and SELinux.

- APatch WebUI entry: webroot/index.html redirects to the local WebUI at http://127.0.0.1:8765/.
- This redirect requires APatch WebView to allow navigation to the local HTTP loopback address.

- Theme: background #000000, cards #212121, accent #85AD49. Default SMB username field: user.
- Samba status shows the device IPv4 address and SMB port instead of smbd PID list.
\n- First-run default SMB login: admin / administrator. Existing settings are preserved on update.\n- Default shares on a fresh install: Root (/), Internal (/storage/emulated/0), Removable Storage volumes (mounted SD cards / USB disks under /storage), read/write; the /storage root is not shared.\n- WARNING: The default password is publicly known and the Root share exposes system files. Change the password and use only on a trusted LAN. Android/SELinux mount permissions may still limit USB storage access.\n

Версия 1.1.2: исправлена инициализация пользователя admin при первом запуске/восстановлении настроек. Пароль по умолчанию: administrator. Если вы уже меняли пароль вручную, обновление не должно сбрасывать его после создания маркера.

Версия 1.1.3: поле имени пользователя по умолчанию изменено на user; акцент интерфейса изменён на #85AD49. Общий путь /storage больше не экспортируется целиком: скрипт добавляет только смонтированные тома под /storage, кроме emulated/self.


Версия 1.2.3: компактная двухколоночная панель на порту 8766 (старый WebUI оставлен как резерв на 8765), выбор акцента #ABCDEF / #D8BFD8 / #E52B50, обнаружение SD/USB-томов по /storage и /mnt/media_rw.
